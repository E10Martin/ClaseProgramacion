package model;

import java.util.ArrayList;

public class Clientes  {

    private String nombre, apellidos;
    private  ArrayList<Clientes> listaPersonas = new ArrayList<>();

    public Clientes(String nombre, String apellidos) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        listaPersonas = new ArrayList<>();
    }

    public Clientes() {

        listaPersonas = new ArrayList<>();
    }

    public void anadirCliente(Clientes clientes){
        listaPersonas.add(clientes);
    }

    public void mostrarCliente(){
        for (Clientes clientes:listaPersonas){
            System.out.println(clientes.toString());
        }
    }
    @Override
    public String toString() {
        return "Clientes;" + "nombre= " + nombre + ", apellidos= " + apellidos ;
    }
}
