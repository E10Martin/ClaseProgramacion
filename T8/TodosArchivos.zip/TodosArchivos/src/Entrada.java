import java.io.File;

public class Entrada {

    public static void main(String[] args) {

        TodosArchivos todosArchivos = new TodosArchivos();

        todosArchivos.leerInformacion(new File("C:\\Users\\Usuario DAM1\\Desktop\\BBDD"));
    }
}
