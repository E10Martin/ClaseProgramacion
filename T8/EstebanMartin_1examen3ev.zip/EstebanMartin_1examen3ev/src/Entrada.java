import model.OperacionesFichero;

public class Entrada {

    public static void main(String[] args) {
        //metodo por el cual descifro el codigo
        OperacionesFichero operacionesFichero = new OperacionesFichero();

        operacionesFichero.descifrarTexto(1,"C:\\Users\\Usuario DAM1\\Documents\\GitHub\\ClaseProgramacion\\T8\\EstebanMartin_1examen3ev\\src\\ejercicio1.txt");

    }

}
