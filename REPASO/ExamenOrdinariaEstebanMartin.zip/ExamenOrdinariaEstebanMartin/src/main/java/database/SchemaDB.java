package database;

public interface SchemaDB {

    String DB_NAME = "tienda_ces";
    String TAB_NAME = "productos";
    String COL_ID = "id";
    String COL_NOMBRE = "nombre";
    String COL_PRECIO = "precio";
    String COL_CANTIDAD = "cantidad";
}
