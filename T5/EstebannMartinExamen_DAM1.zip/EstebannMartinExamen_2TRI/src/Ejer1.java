import java.util.ArrayList;
import java.util.Scanner;

public class Ejer1 {

    private Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {

        ArrayList<String> listaProductos = new ArrayList<>();
        listaProductos.add("Panceta");
        listaProductos.add("Jamon");
        listaProductos.add("Fuet");


    }
}
