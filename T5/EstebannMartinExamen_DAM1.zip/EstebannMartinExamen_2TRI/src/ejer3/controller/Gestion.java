package ejer3.controller;

public class Gestion {

    public boolean agregarPersona(String nombre, String apellidos,int telefono, String dni){

        return false;
    }
}
